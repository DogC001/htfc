<!-- 用途：约束真实天玑前端代码改版流程，明确只改样式、尽量不改尺寸和业务逻辑的边界。 -->
# 华泰天玑真实前端代码样式改版细则 v2

## 1. 目标

本文件用于真实天玑前端项目。目标是在理解代码结构的前提下，依据华泰天玑 v2 设计规范修改前端样式，并确保不触碰业务逻辑。

真实代码改版时必须先判断每个样式调整属于哪一类：

- V2 硬规范修正：来自同目录 `./huatai-tianji-design-spec.md` 中的内置 token、字体、按钮、输入、下拉、标签、阴影、圆角规则。
- 落地经验优化：来自同目录 `./page-patterns.md`、`./component-rules.md` 中标注为落地补充的页面结构和组件统一规则。

交付说明中需要明确哪些改动来自 V2 内置硬规范，哪些改动来自落地经验补充。

真实代码样式改版默认优先“换视觉，不换骨架”：

- 尽量不改原有按钮、弹窗、图片、头像、图标、表格列宽、表单控件、卡片、布局容器的尺寸。
- 优先修改颜色、背景、描边、横线/分割线、文字颜色、hover/active/disabled 状态、阴影轻重、局部圆角一致性。
- V2 中的按钮 L/M/S、输入框高度、弹窗宽度等尺寸用于“新建组件、明显不统一、原页面已经破版、用户明确要求统一尺寸”时参考。
- 如果需要改宽高、行高、列宽、图片尺寸、弹窗尺寸、按钮高度、布局栅格，必须先说明原因、影响范围和风险；没有明确必要时不改。
- 原页面可用且业务布局稳定时，不为了贴合规范数值而重排页面。

## 2. 修改前必须定位

开始改代码前，必须先定位：

- 项目技术栈：React、Vue、Angular、原生 HTML、微前端等。
- 样式方案：CSS、Less、Sass、CSS Modules、Tailwind、CSS-in-JS、组件库主题覆盖。
- 页面入口：路由、页面组件、容器组件。
- 组件树：顶部导航、侧栏、内容区、表格、表单、弹窗等。
- 样式入口：页面样式、组件样式、全局变量、主题覆盖。
- 共享影响：目标样式是否会影响其它页面。

## 3. 允许修改

默认允许：

- `.css`
- `.less`
- `.scss`
- `.sass`
- `.module.css`
- `.module.less`
- `.module.scss`
- `tokens.css`
- `variables.scss`
- `theme.less`
- `antd-overrides.less`
- 纯样式对象文件，如 `styles.ts`、`theme.ts`、`tokens.ts`
- Vue 单文件组件里的 `<style>` 区块

默认修改范围优先级：

1. 颜色、背景、边框、分割线、文字色。
2. hover、active、focus、disabled、error、warning、success 状态。
3. 阴影、圆角、透明度、图标颜色。
4. 局部间距微调。
5. 尺寸、宽高、布局结构仅在必要且说明后调整。

谨慎允许，必须先说明：

- JSX 中新增静态 `className`。
- Vue template 中新增静态 `class`。
- 新增只服务于样式定位的 wrapper。
- CSS-in-JS 中的样式对象。

## 4. 禁止修改

- API 请求。
- 请求参数。
- 返回数据处理。
- 路由。
- 菜单权限。
- 状态管理。
- 表单业务校验。
- 按钮事件。
- 弹窗开关逻辑。
- Tab 切换逻辑。
- 埋点。
- 国际化 key。
- mock 数据。
- package 依赖。
- 构建配置。
- 文案业务含义。

## 5. 样式修改优先级

从高到低：

1. 页面局部样式。
2. 目标组件样式。
3. 页面父级限定下的组件覆盖。
4. 组件库主题覆盖。
5. 全局 tokens / variables。
6. 全局 reset。

原则：

- 局部任务不改全局。
- 共享组件修改必须说明影响范围。
- 组件库覆盖选择器要收敛。
- 避免大量 `!important`。
- 尽量保留原有组件尺寸和布局骨架。
- 不因 V2 有推荐尺寸，就主动覆盖真实系统中稳定可用的按钮、弹窗、图片尺寸。

## 6. 全系统统一时的推荐顺序

如果用户要求“全部系统页面样式改版”，按阶段处理：

### 阶段 1：建立 tokens

- 颜色变量。
- 字体变量。
- 间距变量。
- 圆角变量。
- 阴影变量。
- z-index 和状态变量。

### 阶段 2：统一基础组件

- Button。
- Input / Select / DatePicker / Search。
- Table。
- Modal / Drawer。
- Tabs。
- Menu。
- Pagination。
- Tag / Badge。
- Empty / Result。

### 阶段 3：统一页面壳

- 页面背景。
- 顶部导航。
- 左侧导航。
- 工作区玻璃层。
- 内容 surface。

### 阶段 4：逐页面套规范

- 列表页。
- 详情页。
- 表单页。
- 图表页。
- 配置页。
- 权限/空状态页。

## 7. 常见改法

### 页面壳

```css
.page {
  min-height: 100vh;
  background:
    radial-gradient(circle at 8% 12%, rgba(186, 229, 235, 0.72), transparent 30%),
    radial-gradient(circle at 86% 8%, rgba(198, 215, 244, 0.62), transparent 28%),
    linear-gradient(135deg, #eef8fb 0%, #eef4fb 48%, #f4f8fc 100%);
}
```

### 内容面板

```css
.panel {
  border: 1px solid rgba(226, 234, 240, 0.96);
  border-radius: 16px;
  background: #fff;
  box-shadow: 0 18px 48px rgba(83, 128, 166, 0.1);
}
```

### 主按钮

```css
.primaryButton {
  height: 32px;
  border: 0;
  border-radius: 999px;
  padding: 0 18px;
  color: #fff;
  background: linear-gradient(90deg, #4486f5, #72c6dd);
}
```

### 表格行

```css
.table :global(.ant-table-thead > tr > th) {
  color: #56617c;
  background: #f0f4f9;
  font-weight: 700;
}

.table :global(.ant-table-tbody > tr:hover > td) {
  background: rgba(73, 141, 242, 0.06);
}
```

## 8. 需要先问用户的情况

- 现有 DOM 结构无法实现目标样式。
- 需要新增图标库、字体库或组件库。
- 需要替换组件。
- 需要调整业务文案。
- 需要修改交互流程。
- 需要改共享组件但影响范围不明。
- 用户要求“其它不要动”，但目标样式需要跨区域修改。

## 9. 交付必须说明

- 修改了哪些样式文件。
- 是否修改了模板或组件文件。
- 为什么需要修改模板或组件文件。
- 哪些改动来自 V2 内置硬规范。
- 哪些改动来自 v2 落地经验补充。
- 是否影响共享组件。
- 是否运行检查命令。
- 是否存在未验证风险。
